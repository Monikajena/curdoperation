# client/crud_client.py

import requests
from utils.endpoints import (
    get_create_endpoint, get_read_all_endpoint, get_read_single_endpoint,
    get_update_endpoint, get_delete_endpoint
)

def create_resource(resource, payload):
    """Create a new resource."""
    url = get_create_endpoint(resource)
    response = requests.post(url, json=payload)
    if response.status_code == 201:
        return response.json()
    else:
        response.raise_for_status()

def get_all_resources(resource):
    """Retrieve all resources."""
    url = get_read_all_endpoint(resource)
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        response.raise_for_status()

def get_single_resource(resource, resource_id):
    """Retrieve a single resource by ID."""
    url = get_read_single_endpoint(resource, resource_id)
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        response.raise_for_status()

def update_resource(resource, resource_id, updated_data):
    """Update an existing resource by ID."""
    url = get_update_endpoint(resource, resource_id)
    response = requests.put(url, json=updated_data)
    if response.status_code == 200:
        return None
    else:
        response.raise_for_status()

def delete_resource(resource, resource_id):
    """Delete a resource by ID."""
    url = get_delete_endpoint(resource, resource_id)
    response = requests.delete(url)
    if response.status_code == 200:
        return None
    else:
        response.raise_for_status()
