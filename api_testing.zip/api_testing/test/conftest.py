# test/conftest.py

import pytest
from client.crud_client import create_resource, delete_resource
from utils.payloads import unicorn_data


@pytest.fixture
def created_unicorn():
    """Fixture to create a unicorn and clean up after the test."""
    # Create a unicorn before the test
    unicorn = create_resource("unicorns", unicorn_data)

    # Yield the created unicorn for testing
    yield unicorn

    # Cleanup: Delete the unicorn after the test completes
    delete_resource("unicorns", unicorn["_id"])
