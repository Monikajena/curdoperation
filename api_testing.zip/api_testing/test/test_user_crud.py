# test/test_unicorn_crud.py

import json
import pytest
from client.crud_client import create_resource, get_all_resources, get_single_resource, update_resource, delete_resource
from utils.payloads import unicorn_data, updated_unicorn_data

RESOURCE = "unicorns"
CREATED_UNICORN_FILE = "created_unicorn.json"


def test_create_unicorn():
    """Create a unicorn and save the response to a JSON file."""
    unicorn = create_resource(RESOURCE, unicorn_data)

    # Store the response in a JSON file
    with open(CREATED_UNICORN_FILE, 'w') as f:
        json.dump(unicorn, f, indent=4)

    # Ensure the unicorn data is as expected
    assert unicorn["name"] == unicorn_data["name"]
    assert unicorn["age"] == unicorn_data["age"]
    assert unicorn["colour"] == unicorn_data["colour"]
    assert "_id" in unicorn  # Ensure the unicorn has a unique ID


def test_get_unicorns():
    """Retrieve all unicorns."""
    unicorns = get_all_resources(RESOURCE)
    assert isinstance(unicorns, list)
    assert len(unicorns) > 0


def test_get_unicorn():
    """Retrieve a single unicorn using the ID stored in the JSON file."""

    with open(CREATED_UNICORN_FILE, 'r') as f:
        unicorn = json.load(f)

    unicorn_id = unicorn["_id"]
    retrieved_unicorn = get_single_resource(RESOURCE, unicorn_id)

    assert retrieved_unicorn["_id"] == unicorn_id
    assert retrieved_unicorn["name"] == unicorn["name"]


def test_update_unicorn():
    """Update the unicorn's data using the ID stored in the JSON file."""

    with open(CREATED_UNICORN_FILE, 'r') as f:
        unicorn = json.load(f)

    unicorn_id = unicorn["_id"]

    update_resource(RESOURCE, unicorn_id, updated_unicorn_data)

    updated_unicorn = get_single_resource(RESOURCE, unicorn_id)

    assert updated_unicorn["_id"] == unicorn_id
    assert updated_unicorn["name"] == updated_unicorn_data["name"]
    assert updated_unicorn["age"] == updated_unicorn_data["age"]
    assert updated_unicorn["colour"] == updated_unicorn_data["colour"]


def test_delete_unicorn():
    """Delete the unicorn using the ID stored in the JSON file."""

    with open(CREATED_UNICORN_FILE, 'r') as f:
        unicorn = json.load(f)

    unicorn_id = unicorn["_id"]
    delete_resource(RESOURCE, unicorn_id)

    try:
        get_single_resource(RESOURCE, unicorn_id)
        assert False, "Unicorn was not deleted"
    except:
        pass
