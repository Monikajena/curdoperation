# utils/config.py

# BASE_URL = "https://crudcrud.com/api/{unique_id}/users"  # Replace {unique_id} with your API endpoint
BASE_URL = "https://crudcrud.com/api/9d1972e977854d18a92ff48a83e4b6c7"
