
# Example payload for creating a unicorn
unicorn_data = {
    "name": "Sparkle Angel",
    "age": 2,
    "colour": "blue"
}

# Payload for updating a unicorn's details
updated_unicorn_data = {
    "name": "Shiny Sparkle",
    "age": 3,
    "colour": "purple"
}
