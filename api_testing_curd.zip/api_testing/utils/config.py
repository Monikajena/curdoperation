
BASE_URL = "https://crudcrud.com/api/9d1972e977854d18a92ff48a83e4b6c7"
