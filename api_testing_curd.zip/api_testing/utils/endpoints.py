from utils.config import BASE_URL

def get_create_endpoint(resource):
    """Get the endpoint for creating a new resource."""
    return f"{BASE_URL}/{resource}"

def get_read_all_endpoint(resource):
    """Get the endpoint for fetching all resources."""
    return f"{BASE_URL}/{resource}"

def get_read_single_endpoint(resource, resource_id):
    """Get the endpoint for fetching a single resource by ID."""
    return f"{BASE_URL}/{resource}/{resource_id}"

def get_update_endpoint(resource, resource_id):
    """Get the endpoint for updating a resource by ID."""
    return f"{BASE_URL}/{resource}/{resource_id}"

def get_delete_endpoint(resource, resource_id):
    """Get the endpoint for deleting a resource by ID."""
    return f"{BASE_URL}/{resource}/{resource_id}"
