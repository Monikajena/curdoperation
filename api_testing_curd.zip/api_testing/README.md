# Unicorn CRUD API Test Suite

This project is a test suite designed to verify the CRUD (Create, Read, Update, Delete) operations on a Unicorn resource using the `crudcrud.com` API. The test suite is built using Python and the `pytest` testing framework.

## Features

- **Create**: Add new unicorns with attributes such as name, age, and color.
- **Read**: Retrieve a list of all unicorns or a single unicorn using its ID.
- **Update**: Modify the details of an existing unicorn.
- **Delete**: Remove a unicorn from the system.

## Prerequisites

- Python 3.6 or later
- `pip` (Python package manager)

## Install dependencies:
-pip install -r requirements.txt

## Run all the tests with pytest:
Once all dependencies are installed, you can run the test suite using the pytest testing framework.

-pytest tests/

