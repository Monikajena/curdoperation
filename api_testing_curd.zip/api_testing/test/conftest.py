
import pytest
from client.crud_client import create_resource, delete_resource
from utils.payloads import unicorn_data


@pytest.fixture
def created_unicorn():
    """Fixture to create a unicorn and clean up after the test."""
    unicorn = create_resource("unicorns", unicorn_data)

    yield unicorn

    delete_resource("unicorns", unicorn["_id"])
